## Hatchway Front-End Assessment

To run:
1. Run 'npm install'
2. Run 'npm start'

Open http://localhost:3000 to view it in the browser.